package PacoteP;

public class MyClass {
    public static void main(String[] args) throws Exception{
        ConsultaEstoque loja1 = new ConsultaEstoque("Shernows", "Cleber");

        String refrigerante[] = {"Fanta", "Coca-Cola", "Itubaina", "Dolly", "Pepsi", "Sukita", "It"};
        double vlr_refri[] = {4.39, 4.99, 3.99, 2.99, 4.49, 3.69, 1.49};
        int qtd_refri[] = {50, 60, 40, 30, 50, 40, 30};

        loja1.setNome("Lanchonete Lua Nova");
        loja1.setVendedor("Tiago");

        System.out.println(loja1.getNome());
        System.out.println(loja1.getVendedor());

        int i;
        for(i = 0; i < 7; i++) {
            System.out.println("O refrigerante: " + refrigerante[i] + 
                                        " \nCusta: " + vlr_refri[i] + 
                                        " \nQuantidade: " + qtd_refri[i] + 
                                        "\n");
        }
    }
}


/*

Nomes: 
Airton - RGM: 
Gabriel Murça - RGM: 29818737
Kayky Hyan Nunes - RGM: 29610800
Kayky Andrade - RGM: 
Matheus Freitas - RGM: 5529042577
Rodrigo - RGM: 

Análise e Desenvolvimento de Sistemas - ADS
Campus Paulista - Turma 2ºH

 */