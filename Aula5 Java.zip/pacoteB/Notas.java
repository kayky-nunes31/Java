package pacoteB;

public class Notas {
    
    private double participacao;
    private double exercicios;

    public Notas(double partEntrada, double exerEntrada){
        this.participacao = partEntrada;
        this.exercicios = exerEntrada;
    }

    public double calculaNotas(){
        double nf;
        nf = this.participacao + this.exercicios;
        return nf;
    }
}
