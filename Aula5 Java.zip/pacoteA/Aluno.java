package pacoteA;

class Aluno {
    
    private String nome;
    private String rgm;

    public Aluno(String nomeEntrada, String rgmEntrada){
        this.nome = nomeEntrada;
        this.rgm = rgmEntrada;
    }

    public void imprimeAluno(){
        System.out.println(nome + " e " + rgm);
    }
}
