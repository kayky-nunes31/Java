package pacoteA;
import pacoteB.*;
import java.util.Scanner;;

public class App {
    public static void main(String[] args) throws Exception{

        Scanner entrada = new Scanner(System.in);
        double numeroAleatorio = Math.random() * 10;
        int numeroSorteado = (int)numeroAleatorio;
        int numeroEntrada = 0;

        System.out.print("------- Número Sorteado: " + numeroSorteado + "\n");

        do {
            System.out.print("Digite um número de 0 a 10: ");
            numeroEntrada = entrada.nextInt();

            if(numeroEntrada == numeroSorteado){
                System.out.println("Parabéns você acertou!");
            }
            else if(numeroEntrada > 10) {
                System.out.println("Muito Buro/Bura");
            }
            else {
                System.out.println("Perdeu mané!");
            }
        } while(numeroSorteado != numeroEntrada);
        


        entrada.close();



//        Aluno aluno1 = new Aluno("Fulano", "1234");
//        Notas notaAluno1 = new Notas(0.4, 1.2);

//        System.out.println(notaAluno1.calculaNotas());
//        aluno1.imprimeAluno();
    }
}
